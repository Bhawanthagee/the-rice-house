
package classes;
import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Admin implements Serializable{
    
    private String username;
    private String password;
    
    Database db = new Database();
    
    public Admin(){
        
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    public boolean adminLogin(String username , String password) throws SQLException, Exception{
        boolean attempt = false;
        String query="SELECT username , password FROM admin WHERE username= '"+ username +"' and password= '"+password+"' ";
        ResultSet rs = db.getData(query);
        while(rs.next()){
            attempt = true;
        }
       
        return attempt;
    }
}
