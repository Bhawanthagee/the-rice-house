package classes;
import java.sql.ResultSet;
public class Core {
    Database db = new Database();
    
    public ResultSet getCategoryList(){
        ResultSet rs = null; 
        try{
        String query = "SELECT category from item GROUP BY category";
        rs = db.getData(query);
        }catch (Exception e){
        }
        return rs;
    }
    
    public int getNoOfItemsPerCat(String category){
        ResultSet rs = null; 
        int count=0;
        try{
        String query = "SELECT category from item WHERE category='"+ category +"' ";
        rs = db.getData(query);
        while(rs.next()){
            count++;
        }
        }catch (Exception e){
        }
        return count;
    }
    
    public ResultSet getItemsByCategory(String category){
        ResultSet rs = null; 
        try{
        String query = "SELECT * from item WHERE category='"+category+"'";
        rs = db.getData(query);
        }catch (Exception e){
        }
        return rs;
    }
    
    public ResultSet getItemDetails(int id){
        ResultSet rs = null; 
        try{
        String query = "SELECT * from item WHERE id ="+id+" ";
        rs = db.getData(query);
        }catch (Exception e){
        }
        return rs;
    }
    
    public ResultSet getRelatedProd(int id){
        ResultSet rs=null;
        String cat ="";
        try{
        String query = "SELECT category from item WHERE id ="+id+" ";
        rs = db.getData(query);
        while(rs.next()){
            cat = rs.getString("category");
        }
        }catch (Exception e){
        }
        
        
        ResultSet rs2=null;
        try{
        String query = "SELECT * from item WHERE category ='"+cat+"' LIMIT 4";
        rs2 = db.getData(query);
        }catch (Exception e){
        }
        return rs2;
    }
    
    public ResultSet getresult(String val) throws Exception{
        String stdDetails = "select * from item where name like '%"+val+"%';";
        ResultSet res = db.getData(stdDetails);
        return res;
    }
    
    public void updatePurchaseDetails(String customer, int item_id,double price ,int qty ,String date, String address) throws Exception{
        String query ="INSERT INTO purchase_details( customer, item_id, price, qty, date, address) VALUES ('"+customer+"',"+item_id+","+price+","+qty+",'"+date+"','"+address+"')";
                System.out.println(query);
        try{
        db.setData(query);
        }catch (Exception e){

        }finally{
           
        } 
    }
    
    public ResultSet getOrderDetails(String username) throws Exception{
        ResultSet rs= null;
        String query = "SELECT * from purchase_details WHERE customer ='"+username+"' ";
        rs = db.getData(query);
        return rs;
    }
    public boolean checkAvailability(int itemId) throws Exception{
        boolean bool=true;
        ResultSet rs= null;
        int qty=0;
        String query = "SELECT qty from item WHERE id ="+itemId+" ";
        rs = db.getData(query);
        while(rs.next()){
            qty = rs.getInt("qty");
        }
        
        if(qty<=0){
            bool = false;
        }
        return bool;
    }
    
    public void decreaseQty(int itemId) throws Exception{
        String query =" UPDATE item  SET qty = qty-1 WHERE id = '"+itemId+"' ";
        db.setData(query);
    }
     
     public ResultSet searchByName(String searchTag) throws Exception{
         ResultSet rs=null;
         String query= "SELECT * FROM item WHERE name LIKE'%"+searchTag+"%' ";
         rs = db.getData(query);
         return rs;
     }
     
         public void addToCart(String customer, int item_id,double price ,int qty ,String date, String address) throws Exception{
        String query ="INSERT cart( customer, item_id, price, qty, date, address) VALUES ('"+customer+"',"+item_id+","+price+","+qty+",'"+date+"','"+address+"')";
                System.out.println(query);
        try{
        db.setData(query);
        }catch (Exception e){

        }finally{
           
        } 
    }
        public void addToOrder(String customer, String item_id,double price ,String qty ,String date, String address) throws Exception{
        String query ="INSERT cart_order( customer, item_id, price, qty, date, address) VALUES ('"+customer+"','"+item_id+"',"+price+",'"+qty+"','"+date+"','"+address+"')";
                System.out.println(query);
        try{
        db.setData(query);
        }catch (Exception e){

        }finally{
           
        } 
    }
        
}
