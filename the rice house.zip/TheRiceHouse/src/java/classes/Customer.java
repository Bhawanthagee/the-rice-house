package classes;
import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Customer implements Serializable{
    private int id;
    private String fname;
    private String lname;
    private String email;
    private String bday;
    private String tpNo;
    private String address;
    private String status;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    
    Database db = new Database();
    
    public Customer(){
        
    }
    
    public Customer(int id, String fname, String lname, String email,String bday, String tpNo, String address){
        this.id = id;
        this.fname = fname;
        this.lname = lname;
        this.email = email;
        this.bday = bday;
        this.tpNo = tpNo;
        this.address = address;
    }
    public boolean loginAttempt(String username , String password) throws SQLException, Exception{
        boolean attempt = false;
        String query="SELECT email , password FROM customer WHERE email= '"+ username +"' and password= '"+password+"' ";
        ResultSet rs = db.getData(query);
        while(rs.next()){
            attempt = true;
        }
       
        return attempt;
    }
    
    public ResultSet getUserDetails(String username) throws Exception{
        String query="SELECT * FROM customer WHERE email= '"+ username +"' ";
        ResultSet rs = db.getData(query);
        return rs;
    }
    
    public double getTotal(int qty , int itemid){
        double total=0;
        double price=0;
        ResultSet rs;
        
        try{
        String query = "SELECT price from item WHERE id="+itemid+" ";
        rs = db.getData(query);
        while(rs.next()){
            price = Double.parseDouble(rs.getString("price"));
        }
        total = price * qty;
        }catch (Exception e){
            
        }
        return total;
    }
    
    public boolean register(String fname, String lname, String email, String bday, String address,String tpNo, String password){
        String query = "INSERT INTO customer (fname, lname, email, bday, address, tpno,password) VALUES ('"+fname+"','"+lname+"','"+email+"','"+bday+"','"+address+"','"+tpNo+"','"+password+"')";
        System.out.println(query);
        try{
        db.setData(query);
        return true;
        }catch (Exception e){
            
            return false;
        }finally{
           
        } 
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public String getLname() {
        return lname;
    }

    public void setLname(String lname) {
        this.lname = lname;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getBday() {
        return bday;
    }

    public void setBday(String bday) {
        this.bday = bday;
    }

    public String getTpNo() {
        return tpNo;
    }

    public void setTpNo(String tpNo) {
        this.tpNo = tpNo;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}
