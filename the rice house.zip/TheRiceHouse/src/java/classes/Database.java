package classes;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Database {

    static Connection getMyConnection() throws ClassNotFoundException, SQLException {
        Class.forName("com.mysql.jdbc.Driver");
        Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/thericehouse", "root", "");
        return c;
    }

    public ResultSet getData(String sql) throws Exception {

        Statement st = Database.getMyConnection().createStatement();
        ResultSet rset = st.executeQuery(sql);
        return rset;
    }

    public void setData(String sql) throws Exception {

        Statement st = Database.getMyConnection().createStatement();
        st.executeUpdate(sql);
    }
    
}

