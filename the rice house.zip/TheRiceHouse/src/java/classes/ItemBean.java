package classes;
import java.io.Serializable;
public class ItemBean implements Serializable {
    
    Database db = new Database();
    
    private int id;
    private String name;
    private String brand;
    private String category;
    private double price;
    private int qty;
    private String img;
    
    public ItemBean(){
        
    }
    
    public ItemBean(int id , String name, String brand, String category, double price, int qty, String img){
        this.id = id;
        this.name = name;
        this.brand = brand;
        this.category = category;
        this.price = price;
        this.qty = qty;
        this.img = img;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getQty() {
        return qty;
    }

    public void setQty(int qty) {
        this.qty = qty;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }
    
    public void removeItem(int id) throws Exception{
        String query ="DELETE FROM item WHERE id="+id+"";
        System.out.println(query);
        try{
        db.setData(query);
        }catch (Exception e){

        }finally{
           
        } 
        
    }
    
    public void updateItem(int id,String name,String brand,String category,double price,int qty,String image) throws Exception{
        String query ="UPDATE item SET name='"+name+"',brand='"+brand+"',category='"+category+"',price='"+price+"',qty='"+qty+"',image='"+image+"' WHERE id="+id+"";
        System.out.println(query);
        try{
        db.setData(query);
        }catch (Exception e){

        }finally{
           
        } 
        
    }
    
        public void addItem(String name,String brand,String category,double price,int qty,String image) throws Exception{
        String query ="INSERT INTO item(name,brand,category,price,qty,image) VALUES ("+name+"','"+brand+"','"+category+"',"+price+","+qty+",'"+image+"')";
        System.out.println(query);
        try{
        db.setData(query);
        }catch (Exception e){

        }finally{
           
        } 
        
    }
    

}
