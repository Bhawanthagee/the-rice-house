
package classes;

import java.sql.SQLException;
public class NewMain {

    public static void main(String[] args) throws SQLException, Exception {
        Core c = new Core();
        c.decreaseQty(1);
    
}
}
