package servlets;
import classes.Product;
import classes.Cart;
import classes.Core;
import classes.Database;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "AddToCart", urlPatterns = {"/AddToCart"})
public class AddToCart extends HttpServlet {
    Database db = new Database();
    Core functions= new Core();
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, Exception {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        ResultSet rs;
        String qty=null;
        String name=null;
        String brand=null;
        String price=null;
        String category=null;
        String image=null;
        try {

            out.print("servlet");

            HttpSession session = request.getSession();
            if (session.getAttribute("cart") == null) {
                Cart cart = new Cart();
                session.setAttribute("cart", cart);
            }

            Cart cart = (Cart) session.getAttribute("cart");

            int id = Integer.parseInt(request.getParameter("id"));
            qty = request.getParameter("qty");
            rs = functions.getItemDetails(id);
            while(rs.next()){
            name = rs.getString("name");
            brand = rs.getString("brand");
            price = rs.getString("price");
            category = rs.getString("category");
            image = rs.getString("image");
            } 
           
            Product p = new Product();
            p.setPid(id);
            p.setQty(Integer.parseInt(qty));
            p.setBrand(brand);
            p.setCategory(category);
            p.setName(name);
            p.setImage(image);
            p.setPrice(Double.parseDouble(price));
            ArrayList<Product> products = cart.getProducts();
            if (products.contains(p)) {
                int index = 0;
                for (int i = 0; i < products.size(); i++) {
                    if (products.get(i).getPid() == id) {
                        index = i;
                        break;
                    }
                    

                }
                int newQty = products.get(index).getQty() + p.getQty();
                p.setQty(newQty);
                products.set(index, p);
                

            } else {
                products.add(p);
                        try {       
                            DateFormat df = new SimpleDateFormat("dd/MM/yy");
                            Calendar calobj = Calendar.getInstance();
            functions.addToCart(session.getAttribute("username").toString(), p.getPid(), p.getPrice()*p.getQty(), p.getQty(),(String)df.format(calobj.getTime()),"");

        }catch(Exception e){
        }
            }
            response.sendRedirect("public/view_product.jsp?item="+id+" ");
        RequestDispatcher dispatcher = request.getRequestDispatcher("cart.jsp");
        dispatcher.forward(request, response);

        } finally {
            out.close();
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (Exception ex) {
            Logger.getLogger(AddToCart.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (Exception ex) {
            Logger.getLogger(AddToCart.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }

}
