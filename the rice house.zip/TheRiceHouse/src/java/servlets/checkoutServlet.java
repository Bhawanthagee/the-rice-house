package servlets;
import classes.Core;
import classes.Customer;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "checkoutServlet", urlPatterns = {"/checkoutServlet"})
public class checkoutServlet extends HttpServlet {
    Customer cus = new Customer();
    Core functions = new Core();
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        HttpSession session = request.getSession();
        
        int itemId = Integer.parseInt(request.getParameter("itemID"));
        int qty = Integer.parseInt(request.getParameter("qty"));
        String address = request.getParameter("address");
        double price = Double.parseDouble(request.getParameter("total"));

            DateFormat df = new SimpleDateFormat("dd/MM/yy");
            Calendar calobj = Calendar.getInstance();
        try {       
            functions.updatePurchaseDetails(session.getAttribute("username").toString(), itemId, price, qty,(String)df.format(calobj.getTime()),address);
            functions.decreaseQty(itemId);
            response.sendRedirect("public/orderSuccessful.jsp?total="+price+"&address="+address+"&itemId="+itemId+" ");

        }catch(Exception e){
        }finally {
            out.close();
        }
    }
    

}
