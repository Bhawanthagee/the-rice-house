package servlets;
import classes.Core;
import classes.Customer;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "checkoutcart", urlPatterns = {"/checkoutcart"})
public class checkoutcart extends HttpServlet {

    Customer cus = new Customer();
    Core functions = new Core();
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        HttpSession session = request.getSession();
        
        String itemId = request.getParameter("itemID");
        String qty = request.getParameter("qty");
        String address = request.getParameter("address");
        double price = Double.parseDouble(request.getParameter("total"));
        
        
            DateFormat df = new SimpleDateFormat("dd/MM/yy");
            Calendar calobj = Calendar.getInstance();
        try {       
            functions.addToOrder(session.getAttribute("username").toString(), itemId, price, qty,(String)df.format(calobj.getTime()),address);
            session.removeAttribute("cart");
            response.sendRedirect("public/orderSuccessful.jsp?total="+price+"&address="+address+"&itemId="+itemId+" ");

        }catch(Exception e){
        }finally {
            out.close();
        }
        
    }
    @Override
    public String getServletInfo() {
        return "Short description";
    }

}
