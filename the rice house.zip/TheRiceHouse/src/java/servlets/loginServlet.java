package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import classes.Customer;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.HttpSession;

@WebServlet(name = "login", urlPatterns = {"/loginServlet"})
public class loginServlet extends HttpServlet {
    private String msg = "";
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet login</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet login at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        } finally {
            out.close();
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        if("logout".equals(request.getParameter("logout"))){
            HttpSession session = request.getSession();
            session.invalidate();
            response.sendRedirect("public/login.jsp");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        PrintWriter out = response.getWriter();
        if ("login".equals(request.getParameter("login"))) {
            String username = request.getParameter("username");
            String password = request.getParameter("password");
            Customer cus = new Customer();

            try {
                boolean login = cus.loginAttempt(username, password);
                if (login == true) {
                    response.sendRedirect("public/index.jsp");
                    session.setAttribute("username", username);
                    session.setAttribute("auth", true);
                } else {
                    msg ="credentials you entered does not match";
                    response.sendRedirect("public/login.jsp?msg="+msg+" ");
                }

            } catch (Exception ex) {
                Logger.getLogger(loginServlet.class.getName()).log(Level.SEVERE, null, ex);
            }

        }

    }
    
    @Override
    public String getServletInfo() {
        return "Short description";
    }

}
