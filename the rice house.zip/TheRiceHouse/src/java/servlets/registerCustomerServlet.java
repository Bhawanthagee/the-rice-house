package servlets;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import classes.Customer;
import java.net.URLEncoder;
import javax.servlet.http.HttpSession;


@WebServlet(name = "registerCustomerServlet", urlPatterns = {"/registerCustomerServlet"})
public class registerCustomerServlet extends HttpServlet {

    Customer cs = new Customer();
    String msg=null;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    }
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        String fname = request.getParameter("fname");
        String lname = request.getParameter("lname");
        String email = request.getParameter("email");
        String bday = request.getParameter("birthday");
        String address = request.getParameter("address");
        String tpNo = request.getParameter("tpNo");
        String password = request.getParameter("password");
        String confpassword = request.getParameter("confpassword");
        if(confpassword.equals(password)){
        
        boolean valid = cs.register(fname, lname, email, bday, address , tpNo, password);
        if(valid){  
            HttpSession session = request.getSession();
            response.sendRedirect("public/index.jsp");
            session.setAttribute("username", email);
            session.setAttribute("auth", true);
        }else{
            msg = "registration failed";
            response.sendRedirect("public/register.jsp?msg="+URLEncoder.encode(msg, "UTF-8"));
        }}
        else{
            msg = "passwords you endtered do not match";
            response.sendRedirect("public/register.jsp?msg="+URLEncoder.encode(msg, "UTF-8"));
        }
        
        
    }

}
