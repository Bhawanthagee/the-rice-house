-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 02, 2017 at 09:32 AM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `theliquorshop`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `customer` varchar(100) NOT NULL,
  `item_id` int(11) NOT NULL,
  `price` double NOT NULL,
  `qty` int(11) NOT NULL,
  `date` varchar(100) NOT NULL,
  `address` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `customer`, `item_id`, `price`, `qty`, `date`, `address`) VALUES
(1, 'sagi@gmail.com', 4, 79150, 10, '02/05/17', 'hey'),
(2, 'sagi@gmail.com', 7, 10560, 1, '02/05/17', 'hey'),
(3, 'sagi@gmail.com', 2, 10450, 1, '02/05/17', 'hey'),
(4, 'sagi@gmail.com', 11, 5500, 1, '02/05/17', 'hey'),
(5, 'sagi@gmail.com', 2, 10450, 1, '02/05/17', 'hey'),
(6, 'sagi@gmail.com', 2, 104500, 10, '02/05/17', 'hey'),
(7, 'sagi@gmail.com', 11, 55000, 10, '02/05/17', 'hey');

-- --------------------------------------------------------

--
-- Table structure for table `cart_order`
--

CREATE TABLE `cart_order` (
  `id` int(11) NOT NULL,
  `customer` varchar(100) NOT NULL,
  `item_id` varchar(255) NOT NULL,
  `price` double NOT NULL,
  `qty` int(11) NOT NULL,
  `date` varchar(100) NOT NULL,
  `address` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cart_order`
--

INSERT INTO `cart_order` (`id`, `customer`, `item_id`, `price`, `qty`, `date`, `address`) VALUES
(1, 'sagi@gmail.com', '2', 10450, 1, '02/05/17', 'fsvg'),
(2, 'sagi@gmail.com', '2', 104500, 10, '02/05/17', 'fsvg');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `id` int(11) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `bday` date NOT NULL,
  `address` varchar(100) NOT NULL,
  `tpno` int(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `fname`, `lname`, `email`, `bday`, `address`, `tpno`, `password`) VALUES
(3, 'sadas', 'sds', 'aushadikamadawala681@gmail.com', '2017-05-01', 'msa dasd', 0, '123'),
(2, 'adadadad', 'daADS', 'hansajithpd1342@gmail.com', '2017-05-01', 'uyjuju', 11, '011111'),
(4, 'nilesh', 'thilakarathne', 'nilesh@gmail.com', '2017-05-01', 'MAHABAGE', 342264113, 'nilesh'),
(1, 'sagi', 'lorenzo', 'sagi@gmail.com', '0000-00-00', 'fsvg', 767761432, 'sagi123');

-- --------------------------------------------------------

--
-- Table structure for table `item`
--

CREATE TABLE `item` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `brand` varchar(50) NOT NULL,
  `category` varchar(50) NOT NULL,
  `price` double NOT NULL,
  `qty` int(11) NOT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `item`
--

INSERT INTO `item` (`id`, `name`, `brand`, `category`, `price`, `qty`, `image`) VALUES
(1, 'Smirnoff', 'smirnoff', 'vodka', 6400, 97, 'smirnoff.jpg'),
(2, 'Jack daniels', 'jack daniels', 'whiskey', 10450, 46, 'jack.jpg'),
(3, 'Bacardi', 'bacardi', 'rum', 7650, 70, 'bacardi.jpg'),
(4, 'Skyy vodka', 'skyy', 'vodka', 7915, 60, 'skyy.jpg'),
(5, 'Jose cuervo', 'jose cuervo', 'tequila', 6000, 65, 'cuervo.jpg'),
(6, 'Hennessy', 'hennessy', 'whiskey', 18110, 35, 'hennesy.jpg'),
(7, 'Chivas regal', 'chivas', 'whiskey', 10560, 25, 'chivas.jpg'),
(8, 'Johnnie walker double black', 'johnnie walker', 'whiskey', 12340, 30, 'johnnie.jpg'),
(9, 'Johnnie walker black', 'johnnie walker', 'whiskey', 10625, 32, 'Blabel.jpg'),
(10, 'Johnnie walker red', 'johnnie walker', 'whiskey', 7440, 45, 'Rlabel.jpg'),
(11, 'Absolut vodka', 'absolut', 'vodka', 5500, 33, 'absolut.jpg'),
(12, 'Captain morgan', 'captain morgan', 'rum', 5345, 60, 'captain.jpg'),
(13, 'Silver patron', 'patron', 'tequila', 20400, 31, 'patron.jpg'),
(14, 'Grey goose', 'grey goose', 'vodka', 7875, 20, 'grey.jpg'),
(15, 'Finlandia', 'finlandia', 'vodka', 5890, 30, 'finlandia.jpg'),
(16, 'Mount gay rum', 'eclipse', 'rum', 7585, 19, 'mount.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `purchase_details`
--

CREATE TABLE `purchase_details` (
  `id` int(11) NOT NULL,
  `customer` varchar(100) NOT NULL,
  `item_id` int(11) NOT NULL,
  `price` double NOT NULL,
  `qty` int(11) NOT NULL,
  `date` varchar(100) NOT NULL,
  `address` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `purchase_details`
--

INSERT INTO `purchase_details` (`id`, `customer`, `item_id`, `price`, `qty`, `date`, `address`) VALUES
(1, 'sagi@gmail.com', 2, 31350, 3, 'hey', 'fsvg'),
(2, 'sagi@gmail.com', 6, 18110, 1, '01/05/17', 'fsvg'),
(3, 'sagi@gmail.com', 2, 10450, 1, '02/05/17', 'fsvg'),
(4, 'sagi@gmail.com', 11, 5500, 1, '02/05/17', 'fsvg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cart_order`
--
ALTER TABLE `cart_order`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`email`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `item`
--
ALTER TABLE `item`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `purchase_details`
--
ALTER TABLE `purchase_details`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `cart_order`
--
ALTER TABLE `cart_order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `item`
--
ALTER TABLE `item`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `purchase_details`
--
ALTER TABLE `purchase_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
